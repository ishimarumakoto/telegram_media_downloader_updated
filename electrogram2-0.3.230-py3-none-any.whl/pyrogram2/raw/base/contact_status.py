# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ContactStatus(TLObject):  # type: ignore
    """Contact status: online / offline.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ContactStatus

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            contacts.GetStatuses
    """

    QUALNAME = "pyrogram2.raw.base.ContactStatus"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
