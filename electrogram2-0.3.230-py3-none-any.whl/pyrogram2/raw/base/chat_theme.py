# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ChatTheme(TLObject):  # type: ignore
    """A chat theme

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ChatTheme
            ChatThemeUniqueGift
    """

    QUALNAME = "pyrogram2.raw.base.ChatTheme"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
