# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class Document(TLObject):  # type: ignore
    """A document.

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            Document
            DocumentEmpty

    Functions:
        This object can be returned by 4 functions.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            account.UploadTheme
            account.UploadRingtone
            messages.GetDocumentByHash
            messages.GetCustomEmojiDocuments
    """

    QUALNAME = "pyrogram2.raw.base.Document"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
