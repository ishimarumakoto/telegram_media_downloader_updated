# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ExportedChatInvite(TLObject):  # type: ignore
    """Exported chat invite

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ChatInviteExported
            ChatInvitePublicJoinRequests

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            messages.ExportChatInvite
    """

    QUALNAME = "pyrogram2.raw.base.ExportedChatInvite"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
