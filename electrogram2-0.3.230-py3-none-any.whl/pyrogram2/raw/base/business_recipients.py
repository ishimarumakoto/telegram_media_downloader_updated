# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BusinessRecipients(TLObject):  # type: ignore
    """Specifies the chats that can receive Telegram Business away » and greeting » messages.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BusinessRecipients
    """

    QUALNAME = "pyrogram2.raw.base.BusinessRecipients"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
