# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BusinessGreetingMessage(TLObject):  # type: ignore
    """Describes a Telegram Business greeting, automatically sent to new users writing to us in private for the first time, or after a certain inactivity period.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BusinessGreetingMessage
    """

    QUALNAME = "pyrogram2.raw.base.BusinessGreetingMessage"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
