# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class AiComposeTone(TLObject):  # type: ignore
    """Telegram API base type.

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            AiComposeTone
            AiComposeToneDefault

    Functions:
        This object can be returned by 2 functions.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            aicompose.CreateTone
            aicompose.UpdateTone
    """

    QUALNAME = "pyrogram2.raw.base.AiComposeTone"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
