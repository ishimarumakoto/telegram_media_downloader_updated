# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class DefaultHistoryTTL(TLObject):  # type: ignore
    """Contains info about the default value of the Time-To-Live setting, applied to all new chats.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            DefaultHistoryTTL

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            messages.GetDefaultHistoryTTL
    """

    QUALNAME = "pyrogram2.raw.base.DefaultHistoryTTL"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
