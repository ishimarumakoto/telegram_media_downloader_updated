# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class EmojiList(TLObject):  # type: ignore
    """Represents a list of custom emojis.

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            EmojiList
            EmojiListNotModified

    Functions:
        This object can be returned by 5 functions.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            account.GetDefaultProfilePhotoEmojis
            account.GetDefaultGroupPhotoEmojis
            account.GetDefaultBackgroundEmojis
            account.GetChannelRestrictedStatusEmojis
            messages.SearchCustomEmoji
    """

    QUALNAME = "pyrogram2.raw.base.EmojiList"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
