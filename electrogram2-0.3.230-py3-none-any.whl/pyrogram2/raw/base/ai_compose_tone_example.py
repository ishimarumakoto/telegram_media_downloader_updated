# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class AiComposeToneExample(TLObject):  # type: ignore
    """Telegram API base type.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            AiComposeToneExample

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            aicompose.GetToneExample
    """

    QUALNAME = "pyrogram2.raw.base.AiComposeToneExample"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
