# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ForumTopic(TLObject):  # type: ignore
    """Contains information about a forum topic

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ForumTopic
            ForumTopicDeleted
    """

    QUALNAME = "pyrogram2.raw.base.ForumTopic"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
