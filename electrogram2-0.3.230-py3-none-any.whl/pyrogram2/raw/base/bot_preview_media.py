# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BotPreviewMedia(TLObject):  # type: ignore
    """Represents a Main Mini App preview media, see here » for more info.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BotPreviewMedia

    Functions:
        This object can be returned by 3 functions.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            bots.AddPreviewMedia
            bots.EditPreviewMedia
            bots.GetPreviewMedias
    """

    QUALNAME = "pyrogram2.raw.base.BotPreviewMedia"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
