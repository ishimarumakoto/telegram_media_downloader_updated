# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class EmailVerifyPurpose(TLObject):  # type: ignore
    """Email verification purpose

    Constructors:
        This base type has 3 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            EmailVerifyPurposeLoginChange
            EmailVerifyPurposeLoginSetup
            EmailVerifyPurposePassport
    """

    QUALNAME = "pyrogram2.raw.base.EmailVerifyPurpose"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
