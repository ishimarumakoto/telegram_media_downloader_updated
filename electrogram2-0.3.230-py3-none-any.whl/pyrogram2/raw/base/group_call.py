# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class GroupCall(TLObject):  # type: ignore
    """A group call

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            GroupCall
            GroupCallDiscarded
    """

    QUALNAME = "pyrogram2.raw.base.GroupCall"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
