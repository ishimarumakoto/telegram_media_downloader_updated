# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BusinessBotRecipients(TLObject):  # type: ignore
    """Specifies the private chats that a connected business bot » may receive messages and interact with.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BusinessBotRecipients
    """

    QUALNAME = "pyrogram2.raw.base.BusinessBotRecipients"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
