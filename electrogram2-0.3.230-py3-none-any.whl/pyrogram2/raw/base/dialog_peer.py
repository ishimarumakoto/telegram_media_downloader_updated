# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class DialogPeer(TLObject):  # type: ignore
    """Peer, or all peers in a folder

    Constructors:
        This base type has 3 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            DialogPeer
            DialogPeerCommunity
            DialogPeerFolder

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            messages.GetDialogUnreadMarks
    """

    QUALNAME = "pyrogram2.raw.base.DialogPeer"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
