# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BotBusinessConnection(TLObject):  # type: ignore
    """Contains info about a bot business connection.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BotBusinessConnection
    """

    QUALNAME = "pyrogram2.raw.base.BotBusinessConnection"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
