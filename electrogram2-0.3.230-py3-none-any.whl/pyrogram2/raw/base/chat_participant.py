# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ChatParticipant(TLObject):  # type: ignore
    """Details of a group member.

    Constructors:
        This base type has 3 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ChatParticipant
            ChatParticipantAdmin
            ChatParticipantCreator
    """

    QUALNAME = "pyrogram2.raw.base.ChatParticipant"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
