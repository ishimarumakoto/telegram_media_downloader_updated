# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class AccountDaysTTL(TLObject):  # type: ignore
    """Time-to-live of current account

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            AccountDaysTTL

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            account.GetAccountTTL
    """

    QUALNAME = "pyrogram2.raw.base.AccountDaysTTL"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
