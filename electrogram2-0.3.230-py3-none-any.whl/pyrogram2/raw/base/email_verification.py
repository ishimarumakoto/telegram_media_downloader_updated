# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class EmailVerification(TLObject):  # type: ignore
    """Email verification code or token

    Constructors:
        This base type has 3 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            EmailVerificationApple
            EmailVerificationCode
            EmailVerificationGoogle
    """

    QUALNAME = "pyrogram2.raw.base.EmailVerification"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
