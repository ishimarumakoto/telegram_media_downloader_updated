# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BaseTheme(TLObject):  # type: ignore
    """Basic theme settings

    Constructors:
        This base type has 5 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BaseThemeArctic
            BaseThemeClassic
            BaseThemeDay
            BaseThemeNight
            BaseThemeTinted
    """

    QUALNAME = "pyrogram2.raw.base.BaseTheme"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
