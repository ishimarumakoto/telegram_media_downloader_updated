# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class DataJSON(TLObject):  # type: ignore
    """Represent a JSON-encoded object

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            DataJSON

    Functions:
        This object can be returned by 3 functions.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            bots.SendCustomRequest
            bots.InvokeWebViewCustomMethod
            phone.GetCallConfig
    """

    QUALNAME = "pyrogram2.raw.base.DataJSON"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
