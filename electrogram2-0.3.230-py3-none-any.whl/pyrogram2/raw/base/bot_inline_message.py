# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BotInlineMessage(TLObject):  # type: ignore
    """Inline message

    Constructors:
        This base type has 8 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BotInlineMessageMediaAuto
            BotInlineMessageMediaContact
            BotInlineMessageMediaGeo
            BotInlineMessageMediaInvoice
            BotInlineMessageMediaVenue
            BotInlineMessageMediaWebPage
            BotInlineMessageRichMessage
            BotInlineMessageText
    """

    QUALNAME = "pyrogram2.raw.base.BotInlineMessage"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
