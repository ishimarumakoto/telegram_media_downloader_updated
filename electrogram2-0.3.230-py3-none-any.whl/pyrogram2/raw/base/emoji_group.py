# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class EmojiGroup(TLObject):  # type: ignore
    """Represents an emoji category.

    Constructors:
        This base type has 3 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            EmojiGroup
            EmojiGroupGreeting
            EmojiGroupPremium
    """

    QUALNAME = "pyrogram2.raw.base.EmojiGroup"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
