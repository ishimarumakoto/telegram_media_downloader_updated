# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ChannelParticipant(TLObject):  # type: ignore
    """Channel participant

    Constructors:
        This base type has 6 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ChannelParticipant
            ChannelParticipantAdmin
            ChannelParticipantBanned
            ChannelParticipantCreator
            ChannelParticipantLeft
            ChannelParticipantSelf
    """

    QUALNAME = "pyrogram2.raw.base.ChannelParticipant"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
