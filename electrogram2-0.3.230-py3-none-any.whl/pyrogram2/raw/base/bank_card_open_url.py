# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BankCardOpenUrl(TLObject):  # type: ignore
    """Credit card info URL provided by the bank

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BankCardOpenUrl
    """

    QUALNAME = "pyrogram2.raw.base.BankCardOpenUrl"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
