# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class Dialog(TLObject):  # type: ignore
    """Chat info.

    Constructors:
        This base type has 3 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            Dialog
            DialogCommunity
            DialogFolder
    """

    QUALNAME = "pyrogram2.raw.base.Dialog"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
