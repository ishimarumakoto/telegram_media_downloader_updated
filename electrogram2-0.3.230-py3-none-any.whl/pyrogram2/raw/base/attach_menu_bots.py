# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class AttachMenuBots(TLObject):  # type: ignore
    """Represents a list of bot mini apps that can be launched from the attachment menu »

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            AttachMenuBots
            AttachMenuBotsNotModified

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            messages.GetAttachMenuBots
    """

    QUALNAME = "pyrogram2.raw.base.AttachMenuBots"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
