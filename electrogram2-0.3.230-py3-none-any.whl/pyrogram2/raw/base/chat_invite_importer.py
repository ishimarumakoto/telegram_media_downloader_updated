# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ChatInviteImporter(TLObject):  # type: ignore
    """When and which user joined the chat using a chat invite

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ChatInviteImporter
    """

    QUALNAME = "pyrogram2.raw.base.ChatInviteImporter"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
