# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ChatAdminRights(TLObject):  # type: ignore
    """Represents the rights of an admin in a channel/supergroup.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ChatAdminRights
    """

    QUALNAME = "pyrogram2.raw.base.ChatAdminRights"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
