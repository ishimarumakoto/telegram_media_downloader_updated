# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class FileHash(TLObject):  # type: ignore
    """Hash of an uploaded file, to be checked for validity after download

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            FileHash

    Functions:
        This object can be returned by 3 functions.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            upload.ReuploadCdnFile
            upload.GetCdnFileHashes
            upload.GetFileHashes
    """

    QUALNAME = "pyrogram2.raw.base.FileHash"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
