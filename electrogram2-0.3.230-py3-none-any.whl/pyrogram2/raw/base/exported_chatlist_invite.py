# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ExportedChatlistInvite(TLObject):  # type: ignore
    """An exported chat folder deep link ».

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ExportedChatlistInvite

    Functions:
        This object can be returned by 1 function.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            chatlists.EditExportedInvite
    """

    QUALNAME = "pyrogram2.raw.base.ExportedChatlistInvite"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
