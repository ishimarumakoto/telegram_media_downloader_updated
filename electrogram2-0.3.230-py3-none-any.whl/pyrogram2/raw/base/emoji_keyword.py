# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class EmojiKeyword(TLObject):  # type: ignore
    """Emoji keyword

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            EmojiKeyword
            EmojiKeywordDeleted
    """

    QUALNAME = "pyrogram2.raw.base.EmojiKeyword"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
