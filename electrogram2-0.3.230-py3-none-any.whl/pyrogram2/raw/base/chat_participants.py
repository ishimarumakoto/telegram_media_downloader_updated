# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ChatParticipants(TLObject):  # type: ignore
    """Object contains info on group members.

    Constructors:
        This base type has 2 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ChatParticipants
            ChatParticipantsForbidden
    """

    QUALNAME = "pyrogram2.raw.base.ChatParticipants"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
