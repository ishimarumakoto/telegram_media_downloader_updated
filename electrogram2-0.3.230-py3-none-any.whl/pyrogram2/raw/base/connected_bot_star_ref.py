# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class ConnectedBotStarRef(TLObject):  # type: ignore
    """Info about an active affiliate program we have with a Mini App

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            ConnectedBotStarRef
    """

    QUALNAME = "pyrogram2.raw.base.ConnectedBotStarRef"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
