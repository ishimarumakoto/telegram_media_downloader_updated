# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class BusinessChatLink(TLObject):  # type: ignore
    """Contains info about a business chat deep link » created by the current account.

    Constructors:
        This base type has 1 constructor available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            BusinessChatLink

    Functions:
        This object can be returned by 2 functions.

        .. currentmodule:: pyrogram2.raw.functions

        .. autosummary::
            :nosignatures:

            account.CreateBusinessChatLink
            account.EditBusinessChatLink
    """

    QUALNAME = "pyrogram2.raw.base.BusinessChatLink"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
