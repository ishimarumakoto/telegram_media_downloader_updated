# # # # # # # # # # # # # # # # # # # # # # # #
#               !!! WARNING !!!               #
#          This is a generated file!          #
# All changes made in this file will be lost! #
# # # # # # # # # # # # # # # # # # # # # # # #

from __future__ import annotations

from pyrogram2.raw.core import TLObject

class EmojiStatus(TLObject):  # type: ignore
    """Emoji status

    Constructors:
        This base type has 4 constructors available.

        .. currentmodule:: pyrogram2.raw.types

        .. autosummary::
            :nosignatures:

            EmojiStatus
            EmojiStatusCollectible
            EmojiStatusEmpty
            InputEmojiStatusCollectible
    """

    QUALNAME = "pyrogram2.raw.base.EmojiStatus"

    def __init__(self):
        raise TypeError("Base types can only be used for type checking purposes")
