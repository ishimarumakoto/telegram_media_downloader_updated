from __future__ import annotations

from typing import TYPE_CHECKING

from .handler import Handler

if TYPE_CHECKING:
    from collections.abc import Callable


class PreCheckoutQueryHandler(Handler):
    """The PreCheckoutQueryHandler handler class. Used to handle pre-checkout queries coming from buy buttons.
    It is intended to be used with :meth:`~pyrogram2.Client.add_handler`

    For a nicer way to register this handler, have a look at the
    :meth:`~pyrogram2.Client.on_pre_checkout_query` decorator.

    Parameters:
        callback (``Callable``):
            Pass a function that will be called when a new PreCheckoutQuery arrives. It takes *(client, pre_checkout_query)*
            as positional arguments (look at the section below for a detailed description).

        filters (:obj:`Filters`):
            Pass one or more filters to allow only a subset of callback queries to be passed
            in your callback function.

    Other parameters:
        client (:obj:`~pyrogram2.Client`):
            The Client itself, useful when you want to call other API methods inside the message handler.

        pre_checkout_query (:obj:`~pyrogram2.types.PreCheckoutQuery`):
            New incoming pre-checkout query. Contains full information about checkout.

    """

    def __init__(self, callback: Callable, filters=None) -> None:
        super().__init__(callback, filters)
