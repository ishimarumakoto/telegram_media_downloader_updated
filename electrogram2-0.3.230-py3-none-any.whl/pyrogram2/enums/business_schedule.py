from __future__ import annotations

from pyrogram2 import raw

from .auto_name import AutoName


class BusinessSchedule(AutoName):
    """Business away enumeration used in :obj:`~pyrogram2.types.BusinessInfo`."""

    ALWAYS = raw.types.BusinessAwayMessageScheduleAlways
    "Send always"

    OUTSIDE_WORK_HOURS = raw.types.BusinessAwayMessageScheduleOutsideWorkHours
    "Outside of Business Hours"

    CUSTOM = raw.types.BusinessAwayMessageScheduleCustom
    "Custom Schedule"
