from __future__ import annotations

from typing import TYPE_CHECKING

import pyrogram2
from pyrogram2.filters import Filter

if TYPE_CHECKING:
    from collections.abc import Callable


class OnDeletedMessages:
    def on_deleted_messages(self=None, filters=None, group: int = 0) -> Callable:
        """Decorator for handling deleted messages.

        This does the same thing as :meth:`~pyrogram2.Client.add_handler` using the
        :obj:`~pyrogram2.handlers.DeletedMessagesHandler`.

        Parameters:
            filters (:obj:`~pyrogram2.filters`, *optional*):
                Pass one or more filters to allow only a subset of messages to be passed
                in your function.

            group (``int``, *optional*):
                The group identifier, defaults to 0.
        """

        def decorator(func: Callable) -> Callable:
            if isinstance(self, pyrogram2.Client):
                self.add_handler(
                    pyrogram2.handlers.DeletedMessagesHandler(func, filters),
                    group,
                )
            elif isinstance(self, Filter) or self is None:
                if not hasattr(func, "handlers"):
                    func.handlers = []

                func.handlers.append(
                    (
                        pyrogram2.handlers.DeletedMessagesHandler(func, self),
                        group if filters is None else filters,
                    ),
                )

            return func

        return decorator
