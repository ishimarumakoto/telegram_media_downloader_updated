from __future__ import annotations

from typing import TYPE_CHECKING

import pyrogram2

if TYPE_CHECKING:
    from collections.abc import Callable


class OnDisconnect:
    def on_disconnect(self=None) -> Callable:
        """Decorator for handling disconnections.

        This does the same thing as :meth:`~pyrogram2.Client.add_handler` using the
        :obj:`~pyrogram2.handlers.DisconnectHandler`.
        """

        def decorator(func: Callable) -> Callable:
            if isinstance(self, pyrogram2.Client):
                self.add_handler(pyrogram2.handlers.DisconnectHandler(func))
            else:
                if not hasattr(func, "handlers"):
                    func.handlers = []

                func.handlers.append((pyrogram2.handlers.DisconnectHandler(func), 0))

            return func

        return decorator
