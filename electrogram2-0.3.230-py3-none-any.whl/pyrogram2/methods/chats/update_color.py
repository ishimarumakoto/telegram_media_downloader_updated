from __future__ import annotations

from typing import cast

import pyrogram2
from pyrogram2 import enums, raw, utils


class UpdateColor:
    async def update_color(
        self: pyrogram2.Client,
        chat_id: int | str,
        color: enums.ReplyColor | enums.ProfileColor,
        background_emoji_id: int | None = None,
    ) -> bool:
        """Update color

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                You can also use chat public link in form of *t.me/<username>* (str).

            color (:obj:`~pyrogram2.enums.ReplyColor` | :obj:`~pyrogram2.enums.ProfileColor`):
                Color type.
                Profile color can only be set for the user.

            background_emoji_id (``int``, *optional*):
                Unique identifier of the custom emoji.

        Returns:
            ``bool``: On success, in case the passed-in session is authorized, True is returned.

        Example:
            .. code-block:: python

                await app.update_color(chat_id, enums.ReplyColor.RED)
        """
        peer = await self.resolve_peer(chat_id)

        if isinstance(peer, raw.types.InputPeerSelf):
            r = await self.invoke(
                raw.functions.account.UpdateColor(
                    for_profile=isinstance(color, enums.ProfileColor),
                    color=raw.types.PeerColor(
                        color=color.value,
                        background_emoji_id=background_emoji_id,
                    ),
                ),
            )
        else:
            r = await self.invoke(
                raw.functions.channels.UpdateColor(
                    channel=cast(
                        "raw.base.InputChannel", utils.get_input_channel(peer)
                    ),
                    color=color.value,
                    background_emoji_id=background_emoji_id,
                ),
            )

        return bool(r)
