from __future__ import annotations

from typing import cast

import pyrogram2
from pyrogram2 import raw, utils


class SetSlowMode:
    async def set_slow_mode(
        self: pyrogram2.Client,
        chat_id: int | str,
        seconds: int | None,
    ) -> bool:
        """Set the slow mode interval for a chat.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                You can also use chat public link in form of *t.me/<username>* (str).

            seconds (``int`` | ``None``):
                Seconds in which members will be able to send only one message per this interval.
                Valid values are: 0 or None (off), 10, 30, 60 (1m), 300 (5m), 900 (15m) or 3600 (1h).

        Returns:
            ``bool``: True on success.

        Example:
            .. code-block:: python

                # Set slow mode to 60 seconds
                await app.set_slow_mode(chat_id, 60)

                # Disable slow mode
                await app.set_slow_mode(chat_id, None)
        """

        await self.invoke(
            raw.functions.channels.ToggleSlowMode(
                channel=cast(
                    "raw.base.InputChannel",
                    utils.get_input_channel(await self.resolve_peer(chat_id)),
                ),
                seconds=seconds or 0,
            ),
        )

        return True
