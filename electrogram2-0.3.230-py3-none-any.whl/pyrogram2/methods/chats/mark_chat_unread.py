from __future__ import annotations

import pyrogram2
from pyrogram2 import raw, utils


class MarkChatUnread:
    async def mark_chat_unread(
        self: pyrogram2.Client,
        chat_id: int | str,
    ) -> bool:
        """Mark a chat as unread.

        .. include:: /_includes/usable-by/users.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                You can also use chat public link in form of *t.me/<username>* (str).

        Returns:
            ``bool``: On success, True is returned.
        """

        return await self.invoke(
            raw.functions.messages.MarkDialogUnread(
                peer=raw.types.InputDialogPeer(
                    peer=utils.get_input_peer(await self.resolve_peer(chat_id))
                ),
                unread=True,
            ),
        )
