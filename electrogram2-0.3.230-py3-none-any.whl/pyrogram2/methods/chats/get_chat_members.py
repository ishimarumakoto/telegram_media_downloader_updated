from __future__ import annotations

import logging
from typing import TYPE_CHECKING, cast

import pyrogram2
from pyrogram2 import enums, raw, types, utils

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

log = logging.getLogger(__name__)


async def get_chunk(
    client: pyrogram2.Client,
    chat_id: int | str,
    offset: int,
    filter: enums.ChatMembersFilter,
    limit: int,
    query: str,
):
    is_queryable = filter in [
        enums.ChatMembersFilter.SEARCH,
        enums.ChatMembersFilter.BANNED,
        enums.ChatMembersFilter.RESTRICTED,
    ]

    filter = filter.value(q=query) if is_queryable else filter.value()

    r = await client.invoke(
        raw.functions.channels.GetParticipants(
            channel=cast(
                "raw.base.InputChannel",
                utils.get_input_channel(await client.resolve_peer(chat_id)),
            ),
            filter=filter,
            offset=offset,
            limit=limit,
            hash=0,
        ),
        sleep_threshold=60,
    )

    members = r.participants
    users = {u.id: u for u in r.users}
    chats = {c.id: c for c in r.chats}

    return [
        types.ChatMember._parse(client, member, users, chats) for member in members
    ]


class GetChatMembers:
    async def get_chat_members(
        self: pyrogram2.Client,
        chat_id: int | str,
        query: str = "",
        limit: int = 0,
        filter: enums.ChatMembersFilter = enums.ChatMembersFilter.SEARCH,
    ) -> AsyncGenerator[types.ChatMember, None] | None:
        """Get the members list of a chat.

        A chat can be either a basic group, a supergroup or a channel.
        Requires administrator rights in channels.

        .. include:: /_includes/usable-by/users-bots.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                You can also use chat public link in form of *t.me/<username>* (str).

            query (``str``, *optional*):
                Query string to filter members based on their display names and usernames.
                Only applicable to supergroups and channels. Defaults to "" (empty string).
                A query string is applicable only for :obj:`~pyrogram2.enums.ChatMembersFilter.SEARCH`,
                :obj:`~pyrogram2.enums.ChatMembersFilter.BANNED` and :obj:`~pyrogram2.enums.ChatMembersFilter.RESTRICTED`
                filters only.

            limit (``int``, *optional*):
                Limits the number of members to be retrieved.

            filter (:obj:`~pyrogram2.enums.ChatMembersFilter`, *optional*):
                Filter used to select the kind of members you want to retrieve. Only applicable for supergroups
                and channels.

        Returns:
            ``Generator``: On success, a generator yielding :obj:`~pyrogram2.types.ChatMember` objects is returned.

        Example:
            .. code-block:: python

                from pyrogram2 import enums

                # Get members
                async for member in app.get_chat_members(chat_id):
                    print(member)

                # Get administrators
                administrators = []
                async for m in app.get_chat_members(chat_id, filter=enums.ChatMembersFilter.ADMINISTRATORS):
                    administrators.append(m)

                # Get bots
                bots = []
                async for m in app.get_chat_members(chat_id, filter=enums.ChatMembersFilter.BOTS):
                    bots.append(m)
        """
        peer = await self.resolve_peer(chat_id)

        if isinstance(peer, raw.types.InputPeerChat):
            r = await self.invoke(
                raw.functions.messages.GetFullChat(chat_id=peer.chat_id),
            )

            members = getattr(r.full_chat.participants, "participants", [])
            users = {i.id: i for i in r.users}

            for member in members:
                yield types.ChatMember._parse(self, member, users, {})

            return

        current = 0
        offset = 0
        total = abs(limit) or (1 << 31) - 1
        limit = min(200, total)

        while True:
            members = await get_chunk(
                client=self,
                chat_id=chat_id,
                offset=offset,
                filter=filter,
                limit=limit,
                query=query,
            )

            if not members:
                return

            offset += len(members)

            for member in members:
                yield member

                current += 1

                if current >= total:
                    return
