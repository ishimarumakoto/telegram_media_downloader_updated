from __future__ import annotations

import pyrogram2
from pyrogram2 import raw, types


class GetActiveSessions:
    async def get_active_sessions(
        self: pyrogram2.Client,
    ) -> types.ActiveSessions:
        """Returns all active sessions of the current user.
        .. include:: /_includes/usable-by/users.rst
        Returns:
            :obj:`~pyrogram2.types.ActiveSessions`: On success, all the active sessions of the current user is returned.
        """
        r = await self.invoke(raw.functions.account.GetAuthorizations())
        return types.ActiveSessions._parse(r)
