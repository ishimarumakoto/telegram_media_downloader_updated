from __future__ import annotations

import asyncio
import io
import re
from pathlib import Path
from typing import cast

from anyio import Path as AsyncPath

import pyrogram2
from pyrogram2 import raw, types, utils
from pyrogram2.errors import MediaEmpty, RPCError
from pyrogram2.file_id import FileType

from .inline_session import get_session


class EditInlineMedia:
    MAX_RETRIES = 3

    async def edit_inline_media(
        self: pyrogram2.Client,
        inline_message_id: str,
        media: types.InputMedia,
        reply_markup: types.InlineKeyboardMarkup | None = None,
    ) -> bool | None:
        """Edit animation, audio, document, photo or video messages, or replace text with animation, audio, document, photo or video messages.

        When the inline message is edited, a new file can't be uploaded. Use a previously uploaded file via its file_id
        or specify a URL.

        .. include:: /_includes/usable-by/bots.rst

        Parameters:
            inline_message_id (``str``):
                Required if *chat_id* and *message_id* are not specified.
                Identifier of the inline message.

            media (:obj:`~pyrogram2.types.InputMedia`):
                One of the InputMedia objects describing an animation, audio, document, photo or video.

            reply_markup (:obj:`~pyrogram2.types.InlineKeyboardMarkup`, *optional*):
                An InlineKeyboardMarkup object.

        Returns:
            ``bool``: On success, True is returned.

        Example:
            .. code-block:: python

                from pyrogram2.types import InputMediaPhoto, InputMediaVideo, InputMediaAudio

                # Bots only

                # Replace the current media with a local photo
                await app.edit_inline_media(inline_message_id, InputMediaPhoto("new_photo.jpg"))

                # Replace the current media with a local video
                await app.edit_inline_media(inline_message_id, InputMediaVideo("new_video.mp4"))

                # Replace the current media with a local audio
                await app.edit_inline_media(inline_message_id, InputMediaAudio("new_audio.mp3"))
        """
        caption = media.caption
        parse_mode = media.parse_mode

        is_bytes_io = isinstance(media.media, io.BytesIO)
        is_uploaded_file = is_bytes_io or (
            isinstance(media.media, str) and await AsyncPath(media.media).is_file()
        )

        is_external_url = (
            not is_uploaded_file
            and isinstance(media.media, str)
            and re.match(
                "^https?://",
                media.media,
            )
        )

        if is_bytes_io and not hasattr(media.media, "name"):
            media.media.name = "media"

        if is_uploaded_file:
            filename_attribute = [
                raw.types.DocumentAttributeFilename(
                    file_name=cast("io.BytesIO", media.media).name
                    if is_bytes_io
                    else Path(cast("str", media.media)).name,
                ),
            ]
        else:
            filename_attribute = []

        if isinstance(media, types.InputMediaPhoto):
            if is_uploaded_file:
                input_media = raw.types.InputMediaUploadedPhoto(
                    file=cast(
                        "raw.base.InputFile", await self.save_file(media.media)
                    ),
                    spoiler=media.has_spoiler,
                )
            elif is_external_url:
                input_media = raw.types.InputMediaPhotoExternal(
                    url=cast("str", media.media),
                    spoiler=media.has_spoiler,
                )
            else:
                input_media = cast(
                    "raw.types.InputMediaPhoto",
                    utils.get_input_media_from_file_id(
                        cast("str", media.media),
                        FileType.PHOTO,
                    ),
                )
        elif isinstance(media, types.InputMediaVideo):
            if is_uploaded_file:
                input_media = raw.types.InputMediaUploadedDocument(
                    mime_type=(
                        None
                        if is_bytes_io
                        else self.guess_mime_type(cast("str", media.media))
                    )
                    or "video/mp4",
                    thumb=await self.save_file(media.thumb),
                    file=cast(
                        "raw.base.InputFile", await self.save_file(media.media)
                    ),
                    spoiler=media.has_spoiler,
                    attributes=[
                        raw.types.DocumentAttributeVideo(
                            supports_streaming=media.supports_streaming or None,
                            duration=media.duration,
                            w=media.width,
                            h=media.height,
                        ),
                        *filename_attribute,
                    ],
                )
            elif is_external_url:
                input_media = raw.types.InputMediaDocumentExternal(
                    url=cast("str", media.media),
                    spoiler=media.has_spoiler,
                )
            else:
                input_media = utils.get_input_media_from_file_id(
                    cast("str", media.media),
                    FileType.VIDEO,
                )
        elif isinstance(media, types.InputMediaAudio):
            if is_uploaded_file:
                input_media = raw.types.InputMediaUploadedDocument(
                    mime_type=(
                        None
                        if is_bytes_io
                        else self.guess_mime_type(cast("str", media.media))
                    )
                    or "audio/mpeg",
                    thumb=await self.save_file(media.thumb),
                    file=cast(
                        "raw.base.InputFile", await self.save_file(media.media)
                    ),
                    attributes=[
                        raw.types.DocumentAttributeAudio(
                            duration=media.duration,
                            performer=media.performer,
                            title=media.title,
                        ),
                        *filename_attribute,
                    ],
                )
            elif is_external_url:
                input_media = raw.types.InputMediaDocumentExternal(
                    url=cast("str", media.media)
                )
            else:
                input_media = utils.get_input_media_from_file_id(
                    cast("str", media.media),
                    FileType.AUDIO,
                )
        elif isinstance(media, types.InputMediaAnimation):
            if is_uploaded_file:
                input_media = raw.types.InputMediaUploadedDocument(
                    mime_type=(
                        None
                        if is_bytes_io
                        else self.guess_mime_type(cast("str", media.media))
                    )
                    or "video/mp4",
                    thumb=await self.save_file(media.thumb),
                    file=cast(
                        "raw.base.InputFile", await self.save_file(media.media)
                    ),
                    spoiler=media.has_spoiler,
                    attributes=[
                        raw.types.DocumentAttributeVideo(
                            supports_streaming=True,
                            duration=media.duration,
                            w=media.width,
                            h=media.height,
                        ),
                        raw.types.DocumentAttributeAnimated(),
                        *filename_attribute,
                    ],
                    nosound_video=True,
                )
            elif is_external_url:
                input_media = raw.types.InputMediaDocumentExternal(
                    url=cast("str", media.media),
                    spoiler=media.has_spoiler,
                )
            else:
                input_media = utils.get_input_media_from_file_id(
                    cast("str", media.media),
                    FileType.ANIMATION,
                )
        elif isinstance(media, types.InputMediaDocument):
            if is_uploaded_file:
                input_media = raw.types.InputMediaUploadedDocument(
                    mime_type=(
                        None
                        if is_bytes_io
                        else self.guess_mime_type(cast("str", media.media))
                    )
                    or "application/zip",
                    thumb=await self.save_file(media.thumb),
                    file=cast(
                        "raw.base.InputFile", await self.save_file(media.media)
                    ),
                    attributes=filename_attribute,
                    force_file=True,
                )
            elif is_external_url:
                input_media = raw.types.InputMediaDocumentExternal(
                    url=cast("str", media.media)
                )
            else:
                input_media = utils.get_input_media_from_file_id(
                    cast("str", media.media),
                    FileType.DOCUMENT,
                )

        unpacked = utils.unpack_inline_message_id(inline_message_id)
        dc_id = unpacked.dc_id

        session = await get_session(self, dc_id)

        if is_uploaded_file:
            uploaded_media = await self.invoke(
                raw.functions.messages.UploadMedia(
                    peer=raw.types.InputPeerSelf(),
                    media=input_media,
                ),
            )

            actual_media = (
                raw.types.InputMediaPhoto(
                    id=raw.types.InputPhoto(
                        id=uploaded_media.photo.id,
                        access_hash=uploaded_media.photo.access_hash,
                        file_reference=uploaded_media.photo.file_reference,
                    ),
                    spoiler=getattr(media, "has_spoiler", None),
                )
                if isinstance(media, types.InputMediaPhoto)
                else raw.types.InputMediaDocument(
                    id=raw.types.InputDocument(
                        id=uploaded_media.document.id,
                        access_hash=uploaded_media.document.access_hash,
                        file_reference=uploaded_media.document.file_reference,
                    ),
                    spoiler=getattr(media, "has_spoiler", None),
                )
            )
        else:
            actual_media = input_media

        for i in range(self.MAX_RETRIES):
            try:
                parsed_caption = await self.parser.parse(caption, parse_mode)
                return await session.invoke(
                    raw.functions.messages.EditInlineBotMessage(
                        id=unpacked,
                        media=actual_media,
                        reply_markup=await reply_markup.write(self)
                        if reply_markup
                        else None,
                        message=cast("str", parsed_caption["message"]),
                        entities=cast("list", parsed_caption["entities"]),
                    ),
                    sleep_threshold=self.sleep_threshold,
                )
            except RPCError as e:
                if i == self.MAX_RETRIES - 1:
                    raise

                if isinstance(e, MediaEmpty):
                    # Must wait due to a server race condition
                    await asyncio.sleep(1)
        return None
