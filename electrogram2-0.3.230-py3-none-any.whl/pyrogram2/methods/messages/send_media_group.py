from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import TYPE_CHECKING, cast

from anyio import Path as AsyncPath
from pymediainfo import MediaInfo

import pyrogram2
from pyrogram2 import enums, raw, types, utils
from pyrogram2.file_id import FileType

if TYPE_CHECKING:
    from datetime import datetime

log = logging.getLogger(__name__)


class SendMediaGroup:
    # TODO: Add progress parameter
    async def send_media_group(
        self: pyrogram2.Client,
        chat_id: int | str,
        media: list[
            types.InputMediaPhoto
            | types.InputMediaVideo
            | types.InputMediaAudio
            | types.InputMediaDocument
            | types.InputMediaAnimation
        ],
        disable_notification: bool | None = None,
        message_thread_id: int | None = None,
        business_connection_id: str | None = None,
        reply_to_message_id: int | None = None,
        reply_to_story_id: int | None = None,
        reply_to_chat_id: int | str | None = None,
        quote_text: str | None = None,
        quote_entities: list[types.MessageEntity] | None = None,
        parse_mode: enums.ParseMode | None = None,
        schedule_date: datetime | None = None,
        schedule_repeat_period: int | None = None,
        protect_content: bool | None = None,
        allow_paid_broadcast: bool | None = None,
        allow_paid_stars: int | None = None,
        message_effect_id: int | None = None,
        invert_media: bool | None = None,
        quick_reply_shortcut: str | int | None = None,
        send_as: int | str | None = None,
        background: bool | None = None,
        clear_draft: bool | None = None,
        update_stickersets_order: bool | None = None,
    ) -> list[types.Message]:
        """Send a group of photos or videos as an album.

        .. include:: /_includes/usable-by/users-bots.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                For your personal cloud (Saved Messages) you can simply use "me" or "self".
                For a contact that exists in your Telegram address book you can use his phone number (str).
                You can also use chat public link in form of *t.me/<username>* (str).

            media (List of :obj:`~pyrogram2.types.InputMediaPhoto`, :obj:`~pyrogram2.types.InputMediaVideo`, :obj:`~pyrogram2.types.InputMediaAudio`, :obj:`~pyrogram2.types.InputMediaDocument` and :obj:`~pyrogram2.types.InputMediaAnimation`):
                A list describing photos and videos to be sent, must include 2–10 items.

            disable_notification (``bool``, *optional*):
                Sends the message silently.
                Users will receive a notification with no sound.

            message_thread_id (``int``, *optional*):
                Unique identifier for the target message thread (topic) of the forum.
                for forum supergroups only.

            business_connection_id (``str``, *optional*):
                Business connection identifier.
                for business bots only.

            reply_to_message_id (``int``, *optional*):
                If the message is a reply, ID of the original message.

            reply_to_story_id (``int``, *optional*):
                If the message is a reply, ID of the target story.

            reply_to_chat_id (``int`` | ``str``, *optional*):
                Unique identifier for the origin chat.
                for reply to message from another chat.
                You can also use chat public link in form of *t.me/<username>* (str).

            quote_text (``str``, *optional*):
                Text to quote.
                for reply_to_message only.

            quote_entities (List of :obj:`~pyrogram2.types.MessageEntity`, *optional*):
                List of special entities that appear in quote_text, which can be specified instead of *parse_mode*.
                for reply_to_message only.

            parse_mode (:obj:`~pyrogram2.enums.ParseMode`, *optional*):
                By default, quote_text are parsed using both Markdown and HTML styles.
                You can combine both syntaxes together.
                For quote_text.

            schedule_date (:py:obj:`~datetime.datetime`, *optional*):
                Date when the message will be automatically sent.

            schedule_repeat_period (``int``, *optional*):
                Repeat period of the scheduled message.

            protect_content (``bool``, *optional*):
                Protects the contents of the sent message from forwarding and saving.

            allow_paid_broadcast (``bool``, *optional*):
                Pass True to allow the message to ignore regular broadcast limits for a small fee; for bots only.

            allow_paid_stars (``int``, *optional*):
                Amount of stars to pay for the message; for bots only.

            message_effect_id (``int`` ``64-bit``, *optional*):
                Unique identifier of the message effect to be added to the message; for private chats only.

            invert_media (``bool``, *optional*):
                Inverts the position of the media and caption.

            quick_reply_shortcut (``str`` | ``int``, *optional*):
                Quick reply shortcut identifier or name.

            send_as (``int`` | ``str``, *optional*):
                Unique identifier (int) or username (str) of the chat to send the message as.

            background (``bool``, *optional*):
                Pass True to send the message in the background.

            clear_draft (``bool``, *optional*):
                Pass True to clear the draft.

            update_stickersets_order (``bool``, *optional*):
                Pass True to update the stickersets order.

        Returns:
            List of :obj:`~pyrogram2.types.Message`: On success, a list of the sent messages is returned.

        Example:
            .. code-block:: python

                from pyrogram2.types import InputMediaPhoto, InputMediaVideo

                await app.send_media_group(
                    "me",
                    [
                        InputMediaPhoto("photo1.jpg"),
                        InputMediaPhoto("photo2.jpg", caption="photo caption"),
                        InputMediaVideo("video.mp4", caption="video caption")
                    ]
                )
        """
        multi_media = []

        reply_to = await utils.get_reply_to(
            client=self,
            chat_id=chat_id,
            reply_to_message_id=reply_to_message_id,
            reply_to_story_id=reply_to_story_id,
            message_thread_id=message_thread_id,
            reply_to_chat_id=reply_to_chat_id,
            quote_text=quote_text,
            quote_entities=quote_entities,
            parse_mode=parse_mode,
        )

        for i in media:
            if isinstance(i, types.InputMediaPhoto):
                if isinstance(i.media, str):
                    if await AsyncPath(i.media).is_file():
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaUploadedPhoto(
                                    file=cast(
                                        "raw.base.InputFile",
                                        await self.save_file(i.media),
                                    ),
                                    spoiler=i.has_spoiler,
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaPhoto(
                            id=raw.types.InputPhoto(
                                id=uploaded_media.photo.id,
                                access_hash=uploaded_media.photo.access_hash,
                                file_reference=uploaded_media.photo.file_reference,
                            ),
                            spoiler=i.has_spoiler,
                        )
                    elif re.match("^https?://", i.media):
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaPhotoExternal(
                                    url=i.media,
                                    spoiler=i.has_spoiler,
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaPhoto(
                            id=raw.types.InputPhoto(
                                id=uploaded_media.photo.id,
                                access_hash=uploaded_media.photo.access_hash,
                                file_reference=uploaded_media.photo.file_reference,
                            ),
                            spoiler=i.has_spoiler,
                        )
                    else:
                        input_media = utils.get_input_media_from_file_id(
                            i.media,
                            FileType.PHOTO,
                        )
                else:
                    uploaded_media = await self.invoke(
                        raw.functions.messages.UploadMedia(
                            peer=cast(
                                "raw.base.InputPeer",
                                await self.resolve_peer(chat_id),
                            ),
                            media=raw.types.InputMediaUploadedPhoto(
                                file=cast(
                                    "raw.base.InputFile",
                                    await self.save_file(i.media),
                                ),
                                spoiler=i.has_spoiler,
                            ),
                        ),
                    )

                    input_media = raw.types.InputMediaPhoto(
                        id=raw.types.InputPhoto(
                            id=uploaded_media.photo.id,
                            access_hash=uploaded_media.photo.access_hash,
                            file_reference=uploaded_media.photo.file_reference,
                        ),
                        spoiler=i.has_spoiler,
                    )
            elif isinstance(i, types.InputMediaVideo | types.InputMediaAnimation):
                if isinstance(i.media, str):
                    is_animation = False
                    if await AsyncPath(i.media).is_file():
                        try:
                            videoInfo = MediaInfo.parse(i.media)
                        except OSError:
                            is_animation = bool(
                                isinstance(i, types.InputMediaAnimation),
                            )
                        else:
                            if not any(
                                track.track_type == "Audio"
                                for track in videoInfo.tracks
                            ):
                                is_animation = True
                        attributes = [
                            raw.types.DocumentAttributeVideo(
                                supports_streaming=True
                                if is_animation
                                else (i.supports_streaming or None),
                                duration=i.duration,
                                w=i.width,
                                h=i.height,
                            ),
                            raw.types.DocumentAttributeFilename(
                                file_name=Path(i.media).name,
                            ),
                        ]
                        if is_animation:
                            attributes.append(raw.types.DocumentAttributeAnimated())
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaUploadedDocument(
                                    file=cast(
                                        "raw.base.InputFile",
                                        await self.save_file(i.media),
                                    ),
                                    thumb=await self.save_file(i.thumb),
                                    spoiler=i.has_spoiler,
                                    mime_type=self.guess_mime_type(i.media)
                                    or "video/mp4",
                                    nosound_video=is_animation,
                                    attributes=attributes,
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaDocument(
                            id=raw.types.InputDocument(
                                id=uploaded_media.document.id,
                                access_hash=uploaded_media.document.access_hash,
                                file_reference=uploaded_media.document.file_reference,
                            ),
                            spoiler=i.has_spoiler,
                        )
                    elif re.match("^https?://", i.media):
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaDocumentExternal(
                                    url=i.media,
                                    spoiler=i.has_spoiler,
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaDocument(
                            id=raw.types.InputDocument(
                                id=uploaded_media.document.id,
                                access_hash=uploaded_media.document.access_hash,
                                file_reference=uploaded_media.document.file_reference,
                            ),
                            spoiler=i.has_spoiler,
                        )
                    else:
                        input_media = utils.get_input_media_from_file_id(
                            i.media,
                            FileType.VIDEO,
                        )
                else:
                    uploaded_media = await self.invoke(
                        raw.functions.messages.UploadMedia(
                            peer=cast(
                                "raw.base.InputPeer",
                                await self.resolve_peer(chat_id),
                            ),
                            media=raw.types.InputMediaUploadedDocument(
                                file=cast(
                                    "raw.base.InputFile",
                                    await self.save_file(i.media),
                                ),
                                thumb=await self.save_file(i.thumb),
                                spoiler=i.has_spoiler,
                                mime_type=self.guess_mime_type(
                                    getattr(i.media, "name", "video.mp4"),
                                )
                                or "video/mp4",
                                attributes=[
                                    raw.types.DocumentAttributeVideo(
                                        supports_streaming=i.supports_streaming
                                        or None,
                                        duration=i.duration,
                                        w=i.width,
                                        h=i.height,
                                    ),
                                    raw.types.DocumentAttributeFilename(
                                        file_name=getattr(
                                            i.media,
                                            "name",
                                            "video.mp4",
                                        ),
                                    ),
                                ],
                            ),
                        ),
                    )

                    input_media = raw.types.InputMediaDocument(
                        id=raw.types.InputDocument(
                            id=uploaded_media.document.id,
                            access_hash=uploaded_media.document.access_hash,
                            file_reference=uploaded_media.document.file_reference,
                        ),
                        spoiler=i.has_spoiler,
                    )
            elif isinstance(i, types.InputMediaAudio):
                if isinstance(i.media, str):
                    if await AsyncPath(i.media).is_file():
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaUploadedDocument(
                                    mime_type=self.guess_mime_type(i.media)
                                    or "audio/mpeg",
                                    file=cast(
                                        "raw.base.InputFile",
                                        await self.save_file(i.media),
                                    ),
                                    thumb=await self.save_file(i.thumb),
                                    attributes=[
                                        raw.types.DocumentAttributeAudio(
                                            duration=i.duration,
                                            performer=i.performer,
                                            title=i.title,
                                        ),
                                        raw.types.DocumentAttributeFilename(
                                            file_name=Path(i.media).name,
                                        ),
                                    ],
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaDocument(
                            id=raw.types.InputDocument(
                                id=uploaded_media.document.id,
                                access_hash=uploaded_media.document.access_hash,
                                file_reference=uploaded_media.document.file_reference,
                            ),
                        )
                    elif re.match("^https?://", i.media):
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaDocumentExternal(
                                    url=i.media,
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaDocument(
                            id=raw.types.InputDocument(
                                id=uploaded_media.document.id,
                                access_hash=uploaded_media.document.access_hash,
                                file_reference=uploaded_media.document.file_reference,
                            ),
                        )
                    else:
                        input_media = utils.get_input_media_from_file_id(
                            i.media,
                            FileType.AUDIO,
                        )
                else:
                    uploaded_media = await self.invoke(
                        raw.functions.messages.UploadMedia(
                            peer=cast(
                                "raw.base.InputPeer",
                                await self.resolve_peer(chat_id),
                            ),
                            media=raw.types.InputMediaUploadedDocument(
                                mime_type=self.guess_mime_type(
                                    getattr(i.media, "name", "audio.mp3"),
                                )
                                or "audio/mpeg",
                                file=cast(
                                    "raw.base.InputFile",
                                    await self.save_file(i.media),
                                ),
                                thumb=await self.save_file(i.thumb),
                                attributes=[
                                    raw.types.DocumentAttributeAudio(
                                        duration=i.duration,
                                        performer=i.performer,
                                        title=i.title,
                                    ),
                                    raw.types.DocumentAttributeFilename(
                                        file_name=getattr(
                                            i.media,
                                            "name",
                                            "audio.mp3",
                                        ),
                                    ),
                                ],
                            ),
                        ),
                    )

                    input_media = raw.types.InputMediaDocument(
                        id=raw.types.InputDocument(
                            id=uploaded_media.document.id,
                            access_hash=uploaded_media.document.access_hash,
                            file_reference=uploaded_media.document.file_reference,
                        ),
                    )
            elif isinstance(i, types.InputMediaDocument):
                if isinstance(i.media, str):
                    if await AsyncPath(i.media).is_file():
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaUploadedDocument(
                                    mime_type=self.guess_mime_type(i.media)
                                    or "application/zip",
                                    file=cast(
                                        "raw.base.InputFile",
                                        await self.save_file(i.media),
                                    ),
                                    thumb=await self.save_file(i.thumb),
                                    attributes=[
                                        raw.types.DocumentAttributeFilename(
                                            file_name=Path(i.media).name,
                                        ),
                                    ],
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaDocument(
                            id=raw.types.InputDocument(
                                id=uploaded_media.document.id,
                                access_hash=uploaded_media.document.access_hash,
                                file_reference=uploaded_media.document.file_reference,
                            ),
                        )
                    elif re.match("^https?://", i.media):
                        uploaded_media = await self.invoke(
                            raw.functions.messages.UploadMedia(
                                peer=cast(
                                    "raw.base.InputPeer",
                                    await self.resolve_peer(chat_id),
                                ),
                                media=raw.types.InputMediaDocumentExternal(
                                    url=i.media,
                                ),
                            ),
                        )

                        input_media = raw.types.InputMediaDocument(
                            id=raw.types.InputDocument(
                                id=uploaded_media.document.id,
                                access_hash=uploaded_media.document.access_hash,
                                file_reference=uploaded_media.document.file_reference,
                            ),
                        )
                    else:
                        input_media = utils.get_input_media_from_file_id(
                            i.media,
                            FileType.DOCUMENT,
                        )
                else:
                    uploaded_media = await self.invoke(
                        raw.functions.messages.UploadMedia(
                            peer=cast(
                                "raw.base.InputPeer",
                                await self.resolve_peer(chat_id),
                            ),
                            media=raw.types.InputMediaUploadedDocument(
                                mime_type=self.guess_mime_type(
                                    getattr(i.media, "name", "file.zip"),
                                )
                                or "application/zip",
                                file=cast(
                                    "raw.base.InputFile",
                                    await self.save_file(i.media),
                                ),
                                thumb=await self.save_file(i.thumb),
                                attributes=[
                                    raw.types.DocumentAttributeFilename(
                                        file_name=getattr(
                                            i.media,
                                            "name",
                                            "file.zip",
                                        ),
                                    ),
                                ],
                            ),
                        ),
                    )

                    input_media = raw.types.InputMediaDocument(
                        id=raw.types.InputDocument(
                            id=uploaded_media.document.id,
                            access_hash=uploaded_media.document.access_hash,
                            file_reference=uploaded_media.document.file_reference,
                        ),
                    )
            else:
                raise ValueError(
                    f"{i.__class__.__name__} is not a supported type for send_media_group",
                )

            parsed_caption = await self.parser.parse(i.caption, i.parse_mode)
            multi_media.append(
                raw.types.InputSingleMedia(
                    media=input_media,
                    random_id=self.rnd_id(),
                    message=cast("str", parsed_caption["message"]),
                    entities=cast("list", parsed_caption["entities"]),
                ),
            )

        rpc = raw.functions.messages.SendMultiMedia(
            peer=utils.get_input_peer(await self.resolve_peer(chat_id)),
            multi_media=multi_media,
            silent=disable_notification or None,
            reply_to=reply_to,
            schedule_date=utils.datetime_to_timestamp(schedule_date),
            noforwards=protect_content,
            allow_paid_floodskip=allow_paid_broadcast,
            effect=message_effect_id,
            invert_media=invert_media,
            background=background,
            clear_draft=clear_draft,
            update_stickersets_order=update_stickersets_order,
            send_as=utils.get_input_peer(await self.resolve_peer(send_as)),
            quick_reply_shortcut=await utils.get_input_quick_reply_shortcut(
                quick_reply_shortcut,
            )
            if quick_reply_shortcut
            else None,
            allow_paid_stars=allow_paid_stars,
        )

        if business_connection_id is not None:
            r = await self.invoke(
                raw.functions.InvokeWithBusinessConnection(
                    connection_id=business_connection_id,
                    query=rpc,
                ),
                sleep_threshold=60,
            )
        else:
            r = await self.invoke(rpc, sleep_threshold=60)

        return await utils.parse_messages(
            self,
            raw.types.messages.Messages(
                messages=[
                    m.message
                    for m in filter(
                        lambda u: isinstance(
                            u,
                            raw.types.UpdateNewMessage
                            | raw.types.UpdateNewChannelMessage
                            | raw.types.UpdateNewScheduledMessage
                            | raw.types.UpdateBotNewBusinessMessage,
                        ),
                        r.updates,
                    )
                ],
                topics=[],
                users=r.users,
                chats=r.chats,
            ),
            business_connection_id=business_connection_id or "",
        )
