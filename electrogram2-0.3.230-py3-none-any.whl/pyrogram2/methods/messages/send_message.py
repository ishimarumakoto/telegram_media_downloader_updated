from __future__ import annotations

from typing import TYPE_CHECKING, cast

import pyrogram2
from pyrogram2 import enums, raw, types, utils

if TYPE_CHECKING:
    from datetime import datetime


class SendMessage:
    async def send_message(
        self: pyrogram2.Client,
        chat_id: int | str,
        text: str,
        parse_mode: enums.ParseMode | None = None,
        entities: list[types.MessageEntity] | None = None,
        disable_web_page_preview: bool | None = None,
        disable_notification: bool | None = None,
        message_thread_id: int | None = None,
        business_connection_id: str | None = None,
        reply_to_message_id: int | None = None,
        reply_to_story_id: int | None = None,
        reply_to_chat_id: int | None = None,
        quote_text: str | None = None,
        quote_entities: list[types.MessageEntity] | None = None,
        schedule_date: datetime | None = None,
        schedule_repeat_period: int | None = None,
        protect_content: bool | None = None,
        allow_paid_broadcast: bool | None = None,
        allow_paid_stars: int | None = None,
        invert_media: bool | None = None,
        message_effect_id: int | None = None,
        quick_reply_shortcut: str | int | None = None,
        send_as: int | str | None = None,
        background: bool | None = None,
        clear_draft: bool | None = None,
        update_stickersets_order: bool | None = None,
        suggested_post: types.SuggestedPost | None = None,
        reply_markup: types.InlineKeyboardMarkup
        | types.ReplyKeyboardMarkup
        | types.ReplyKeyboardRemove
        | types.ForceReply
        | None = None,
        rich_message: str | types.InputRichMessage | None = None,
        rich_message_media: types.InputRichMessageMedia
        | list[types.InputRichMessageMedia]
        | None = None,
    ) -> types.Message | None:
        """Send text messages.

        .. include:: /_includes/usable-by/users-bots.rst

        Parameters:
            chat_id (``int`` | ``str``):
                Unique identifier (int) or username (str) of the target chat.
                For your personal cloud (Saved Messages) you can simply use "me" or "self".
                For a contact that exists in your Telegram address book you can use his phone number (str).
                You can also use chat public link in form of *t.me/<username>* (str).

            text (``str``):
                Text of the message to be sent.

            parse_mode (:obj:`~pyrogram2.enums.ParseMode`, *optional*):
                By default, texts are parsed using both Markdown and HTML styles.
                You can combine both syntaxes together.

            entities (List of :obj:`~pyrogram2.types.MessageEntity`):
                List of special entities that appear in message text, which can be specified instead of *parse_mode*.

            disable_web_page_preview (``bool``, *optional*):
                Disables link previews for links in this message.

            disable_notification (``bool``, *optional*):
                Sends the message silently.
                Users will receive a notification with no sound.

            message_thread_id (``int``, *optional*):
                Unique identifier for the target message thread (topic) of the forum.
                for forum supergroups only.

            business_connection_id (``str``, *optional*):
                Business connection identifier.
                for business bots only.

            reply_to_message_id (``int``, *optional*):
                If the message is a reply, ID of the original message.

            reply_to_story_id (``int``, *optional*):
                If the message is a reply, ID of the target story.

            reply_to_chat_id (``int`` | ``str``, *optional*):
                Unique identifier for the origin chat.
                for reply to message from another chat.
                You can also use chat public link in form of *t.me/<username>* (str).

            quote_text (``str``, *optional*):
                Text to quote.
                for reply_to_message only.

            quote_entities (List of :obj:`~pyrogram2.types.MessageEntity`, *optional*):
                List of special entities that appear in quote_text, which can be specified instead of *parse_mode*.
                for reply_to_message only.

            schedule_date (:py:obj:`~datetime.datetime`, *optional*):
                Date when the message will be automatically sent.

            schedule_repeat_period (``int``, *optional*):
                Repeat period of the scheduled message.

            protect_content (``bool``, *optional*):
                Protects the contents of the sent message from forwarding and saving.

            allow_paid_broadcast (``bool``, *optional*):
                Pass True to allow the message to ignore regular broadcast limits for a small fee; for bots only

            allow_paid_stars (``int``, *optional*):
                Amount of stars to pay for the message; for bots only.

            invert_media (``bool``, *optional*):
                Move web page preview to above the message.

            message_effect_id (``int`` ``64-bit``, *optional*):
                Unique identifier of the message effect to be added to the message; for private chats only.

            quick_reply_shortcut (``str`` | ``int``, *optional*):
                Quick reply shortcut identifier or name.

            send_as (``int`` | ``str``, *optional*):
                Unique identifier (int) or username (str) of the chat to send the message as.

            background (``bool``, *optional*):
                Pass True to send the message in the background.

            clear_draft (``bool``, *optional*):
                Pass True to clear the draft.

            update_stickersets_order (``bool``, *optional*):
                Pass True to update the stickersets order.

            suggested_post (:obj:`~pyrogram2.types.SuggestedPost`, *optional*):
                Suggested post information.

            reply_markup (:obj:`~pyrogram2.types.InlineKeyboardMarkup` | :obj:`~pyrogram2.types.ReplyKeyboardMarkup` | :obj:`~pyrogram2.types.ReplyKeyboardRemove` | :obj:`~pyrogram2.types.ForceReply`, *optional*):
                Additional interface options. An object for an inline keyboard, custom reply keyboard,
                instructions to remove reply keyboard or to force a reply from the user.

            rich_message (``str`` | :obj:`~pyrogram2.types.InputRichMessage`, *optional*):
                Send a rich formatted message instead of a plain text one.
                Pass a string with HTML or Markdown content, or an
                :obj:`~pyrogram2.types.InputRichMessage` for full control.
                When provided, *text* is used as the fallback plain text of the message.

            rich_message_media (:obj:`~pyrogram2.types.InputRichMessageMedia` | List of :obj:`~pyrogram2.types.InputRichMessageMedia`, *optional*):
                Media referenced by the rich message.

        Returns:
            :obj:`~pyrogram2.types.Message`: On success, the sent text message is returned.

        Example:
            .. code-block:: python

                # Simple example
                await app.send_message("me", "Message sent with **Pyrogram**!")

                # Disable web page previews
                await app.send_message("me", "https://github.com",
                    disable_web_page_preview=True)

                # Reply to a message using its id
                await app.send_message("me", "this is a reply", reply_to_message_id=123)

            .. code-block:: python

                # For bots only, send messages with keyboards attached

                from pyrogram2.types import (
                    ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton)

                # Send a normal keyboard
                await app.send_message(
                    chat_id, "Look at that button!",
                    reply_markup=ReplyKeyboardMarkup([["Nice!"]]))

                # Send an inline keyboard
                await app.send_message(
                    chat_id, "These are inline buttons",
                    reply_markup=InlineKeyboardMarkup(
                        [
                            [InlineKeyboardButton("Data", callback_data="callback_data")],
                            [InlineKeyboardButton("Docs", url="https://github.com")]
                        ]))
        """

        parsed_text = await utils.parse_text_entities(
            self, text, parse_mode, entities
        )
        message = cast("str", parsed_text["message"])
        entities = cast("list", parsed_text["entities"])

        reply_to = await utils.get_reply_to(
            client=self,
            chat_id=chat_id,
            reply_to_message_id=reply_to_message_id,
            reply_to_story_id=reply_to_story_id,
            message_thread_id=message_thread_id,
            reply_to_chat_id=reply_to_chat_id,
            quote_text=quote_text,
            quote_entities=quote_entities,
            parse_mode=parse_mode,
        )

        rich_message_rpc = None

        if rich_message is not None:
            if isinstance(rich_message, types.InputRichMessage):
                rich_message_rpc = rich_message.write()
            else:
                files = (
                    types.InputRichMessage(
                        html="_", media=rich_message_media
                    ).write_files()
                    if rich_message_media
                    else None
                )

                if parse_mode == enums.ParseMode.HTML:
                    rich_message_rpc = raw.types.InputRichMessageHTML(
                        html=rich_message,
                        files=files,
                    )
                else:
                    rich_message_rpc = raw.types.InputRichMessageMarkdown(
                        markdown=rich_message,
                        files=files,
                    )

        rpc = raw.functions.messages.SendMessage(
            peer=utils.get_input_peer(await self.resolve_peer(chat_id)),
            no_webpage=disable_web_page_preview or None,
            silent=disable_notification or None,
            reply_to=reply_to,
            random_id=self.rnd_id(),
            schedule_date=utils.datetime_to_timestamp(schedule_date),
            reply_markup=await reply_markup.write(self) if reply_markup else None,
            message=message,
            entities=entities,
            noforwards=protect_content,
            allow_paid_floodskip=allow_paid_broadcast,
            invert_media=invert_media,
            effect=message_effect_id,
            background=background,
            clear_draft=clear_draft,
            update_stickersets_order=update_stickersets_order,
            schedule_repeat_period=schedule_repeat_period,
            send_as=utils.get_input_peer(await self.resolve_peer(send_as)),
            quick_reply_shortcut=await utils.get_input_quick_reply_shortcut(
                quick_reply_shortcut,
            )
            if quick_reply_shortcut
            else None,
            allow_paid_stars=allow_paid_stars,
            suggested_post=await suggested_post.write() if suggested_post else None,
            rich_message=rich_message_rpc,
        )
        if business_connection_id is not None:
            r = await self.invoke(
                raw.functions.InvokeWithBusinessConnection(
                    connection_id=business_connection_id,
                    query=rpc,
                ),
            )
        else:
            r = await self.invoke(rpc)

        if isinstance(r, raw.types.UpdateShortSentMessage):
            peer = await self.resolve_peer(chat_id)

            peer_id = (
                peer.user_id
                if isinstance(peer, raw.types.InputPeerUser)
                else -peer.chat_id
            )

            return types.Message(
                id=r.id,
                chat=types.Chat(
                    id=peer_id,
                    type=enums.ChatType.PRIVATE,
                    client=self,
                ),
                text=types.messages_and_media.message.Str(message),
                date=utils.timestamp_to_datetime(r.date),
                outgoing=r.out,
                reply_markup=reply_markup,
                entities=[
                    e
                    for entity in entities
                    if (e := types.MessageEntity._parse(None, entity, {}))
                    is not None
                ]
                if entities
                else None,
                client=self,
            )

        for i in r.updates:
            if isinstance(
                i,
                raw.types.UpdateNewMessage
                | raw.types.UpdateNewChannelMessage
                | raw.types.UpdateNewScheduledMessage
                | raw.types.UpdateBotNewBusinessMessage,
            ):
                return await types.Message._parse(
                    self,
                    i.message,
                    {i.id: i for i in r.users},
                    {i.id: i for i in r.chats},
                    is_scheduled=isinstance(i, raw.types.UpdateNewScheduledMessage),
                    business_connection_id=business_connection_id,
                )
        return None
